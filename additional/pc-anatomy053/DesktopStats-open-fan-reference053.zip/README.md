# 可拆分风扇 · 开源模型参考包

这是 PC Anatomy 教学风扇的独立数据包，保留框架和叶轮两个部件组、九片共享叶片几何。GLB 可供支持 glTF 2.0 的工具读取；目前还不能作为 Stats 的 `.dspack` 导入。

`models/generic-fan-derived.glb` 是本项目修订版，修正叶片绕序和法线分组。`models/generic-fan-original.glb` 是修订前的独立导出，便于比较。两者使用同一坐标与材质，原始模型字节保留。源文件和转换说明见 `SOURCES.json`，检查范围见 `QUALITY.json`。

这是通用教育参考风扇，不对应已核实的零售型号。风扇框架存在四个保留的极小三角面；外形制造精度、安装兼容、实际转速和原生绘制仍未验收。本包不包含机箱、散热器或完整装配。

上游 PC Anatomy © 2026 Yoseph、Three.js 的 MIT 许可与署名均保留于 `licenses/`。这些上游内容和衍生数据继续适用相应许可；DesktopStats 原创内容的非商用条款及自有水印不覆盖它们。
