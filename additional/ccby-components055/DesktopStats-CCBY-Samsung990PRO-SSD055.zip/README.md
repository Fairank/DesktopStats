# Samsung 990 PRO 1TB SSD（作者标题标注参考）

M.2 NVME SSD Samsung 990 Pro 1TB 3D model · lime.ball.animations · CC BY 4.0

https://sketchfab.com/3d-models/41b7bfda7eab40f8b13330913fd66fc2
https://creativecommons.org/licenses/by/4.0/

本包为手动选择、单件加载的开源三维结构参考。六套插画配色共用同一份只读几何；不预载、不自动识别、不自动装配，不绑定本机温度或转速。

保留原始 GLB、索引和 UV、原材质/编码贴图、完整 CC BY 4.0 许可与署名、来源质量报告及本次坐标表示质量记录；未删三角面、重建法线或修整源模型。当前查看器仅显示原几何与颜色因子，未还原贴图、灯光和完整 PBR。比例仅为作者源坐标的显示转换，制造尺寸、孔位、装配兼容性和零售型号精度均未核准。

原模型继续适用 CC BY 4.0，包括该许可允许的商业使用；本项目的非商业条款不覆盖此第三方模型。不添加独占水印或把作者模型标作本项目独有。改动说明见 CHANGES054.txt。
