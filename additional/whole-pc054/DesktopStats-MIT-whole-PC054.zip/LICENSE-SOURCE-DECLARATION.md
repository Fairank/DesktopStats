# 原始许可声明

作者：mohammed rayyan hussain（mdrayyanhussain2006）

来源：https://github.com/mdrayyanhussain2006/pc-components-manual/tree/1aabb3b1a537f47b2d91d83e9113cd9454013c1e

上游项目 README 的原始声明：

> This project is released under the **MIT License**.

此包保留原始 UPSTREAM-README.md 与 SOURCE054.json，未另行捏造上游版权行或许可文件。meshoptimizer 的许可全文见 LICENSE-meshoptimizer.md。第三方 MIT 文件没有附加 NC 限制或我们自己的水印。
